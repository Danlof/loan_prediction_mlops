# Build the package 
`pip install -r requirements.txt`

2 . Create a pickle file after training 
`python prediction_model/training_pipeline.py`

3. Create source distribution and the wheel
`python setup.py sdist bdist_wheel`
