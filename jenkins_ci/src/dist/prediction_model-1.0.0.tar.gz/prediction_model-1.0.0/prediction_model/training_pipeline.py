
import pandas as pd 
import numpy as np 
import sys
import os 
from pathlib import Path

sys.path.append('/media/danlof/dan files/data_science_codes/udemy_course/packaging/prediction_model')


from config import config
from processing import preprocessing
from processing.data_handling import load_dataset,save_pipeline
import pipeline as pipe
PACKAGE_ROOT= '/media/danlof/dan files/data_science_codes/udemy_course/packaging/prediction_model'

def perform_training():
    train_data = load_dataset(config.TRAIN_FILE)
    train_y = train_data[config.TARGET].map({'N':0,'Y':1})
    pipe.classification_pipeline.fit(train_data[config.FEATURES],train_y)
    save_pipeline(pipe.classification_pipeline)
    print("succesful")

if __name__=='__main__':
    perform_training()