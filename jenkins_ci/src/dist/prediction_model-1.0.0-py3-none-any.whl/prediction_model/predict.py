import numpy as np
import pandas as pd 
import joblib
import os 
import pathlib
import sys


PACKAGE_ROOT = sys.path.append('/media/danlof/dan files/data_science_codes/udemy_course/packaging/prediction_model')

from config import config
from processing.data_handling import load_pipeline,load_dataset

# Construct the file path for loading the model

#model_file_path = os.path.join(config.SAVE_MODEL_PATH, config.MODEL_NAME)
#print("Model file path:", model_file_path) 

classification_pipeline = load_pipeline(config.MODEL_NAME)

def generate_predictions(data_input):
    data = pd.DataFrame(data_input)
    pred = classification_pipeline.predict(data[config.FEATURES])
    output = np.where(pred==1,'Y','N')
    result = {"prediction":output}
    return result

# def generate_predictions():
#      test_data = load_dataset(config.TEST_FILE)
#      pred = classification_pipeline.predict(test_data[config.FEATURES])
#      output = np.where(pred==1,'Y','N')
#      print(output)
#      #result = {"Predictions":output}
#      return output

if __name__=='__main__':
    generate_predictions()  